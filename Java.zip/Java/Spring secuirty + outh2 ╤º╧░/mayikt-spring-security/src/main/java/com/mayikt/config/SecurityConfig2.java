//package com.mayikt.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.crypto.password.NoOpPasswordEncoder;
//import org.springframework.stereotype.Component;
//
//@Component
//@EnableWebSecurity
//public class SecurityConfig2 extends WebSecurityConfigurerAdapter {
//    /**
//     * 新增授权账户
//     *
//     * @param auth
//     * @throws Exception
//     */
//    @Override
//    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//        /**
//         * 新增一个账户mayikt 密码也是为mayikt 可以允许访问所有的请求
//         */
//        auth.inMemoryAuthentication().withUser("mayikt").password("mayikt").authorities("/");
//
//        /**
//         * 当前 账户授权 可以访问哪些接口
//         */
//        auth.inMemoryAuthentication().withUser("mayikt_add").password("mayikt_add").authorities("addMember");
//        auth.inMemoryAuthentication().withUser("mayikt_update").password("mayikt_update").authorities("updateMember");
//        auth.inMemoryAuthentication().withUser("mayikt_show").password("mayikt_admin").authorities("showMember");
//        auth.inMemoryAuthentication().withUser("mayikt_del").password("mayikt_del").authorities("delMember");
//    }
//
//    /**
//     * 新增 HttpSecurity配置
//     *
//     * @param http
//     * @throws Exception
//     */
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
////        /**
////         * 拦截 http 安全认证模式 设置为httpBasic模式
////         */
////        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
////                .and().httpBasic();
//
////        /**
////         * 拦截 http 安全认证模式 设置为httpBasic模式
////         */
////        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
////                .and().formLogin();
//        http.authorizeRequests().antMatchers("/addMember").hasAnyAuthority("addMember")
//                .antMatchers("/delMember").hasAnyAuthority("delMember")
//                .antMatchers("/updateMember").hasAnyAuthority("updateMember")
//                .antMatchers("/showMember").hasAnyAuthority("showMember")
//                // 可以允许login 不被拦截
//                .antMatchers("/login").permitAll()
//                // 设置自定义登录页面
//                .antMatchers("/**").fullyAuthenticated().and().formLogin()
//                .loginPage("/login").and().csrf().disable();
//
//    }
//
//    @Bean
//    public static NoOpPasswordEncoder passwordEncoder() {
//        return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
//    }
//}
