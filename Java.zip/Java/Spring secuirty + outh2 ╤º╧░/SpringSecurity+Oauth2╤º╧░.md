

## SpringSecurity + Oauth2 学习

### SpringSecurity

Spring Security是一个能够为基于Spring的企业应用系统提供声明式的安全访问控制解决方案的安全框架。它提供了一组可以在Spring应用上下文中配置的Bean，充分利用了Spring IoC，DI（控制反转Inversion of Control ,DI:Dependency Injection 依赖注入）和AOP（面向切面编程）功能，为应用系统提供声明式的安全访问控制功能，减少了为企业系统安全控制编写大量重复代码的工作。

### 认证模式

#### 实现Basic认证

Basic认证是一种较为简单的HTTP认证方式，客户端通过明文（Base64编码格式）传输用户名和密码到服务端进行认证，通常需要配合HTTPS来保证信息传输的安全。

##### Maven 依赖

```xml
<!--  springboot 整合web组件-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<!--spring-boot-starter-security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-freemarker</artifactId>
</dependency>
```

##### config 类

```Java
@Component
@EnableWebSecurity
public class SecurityConfig2 extends WebSecurityConfigurerAdapter {
    /**
     * 新增授权账户
     *
     * @param auth
     * @throws Exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        /**
         * 新增一个账户mayikt 密码也是为mayikt 可以允许访问所有的请求
         */
        auth.inMemoryAuthentication().withUser("mayikt").password("mayikt").authorities("/");
    }

    /**
     * 新增 HttpSecurity配置
     *
     * @param http
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        /**
         * 拦截 http 安全认证模式 设置为httpBasic模式
         */
        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
                .and().httpBasic();
    }
    @Bean
    public static NoOpPasswordEncoder passwordEncoder() {
        return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
    }
}
```

#### 实现 form 表单认证

将 bacis 模式换成表单模式

```Java
    @Override
    protected void configure(HttpSecurity http) throws Exception {
//        /**
//         * 拦截 http 安全认证模式 设置为httpBasic模式
//         */
//        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
//                .and().httpBasic();

        /**
         * 拦截 http 安全认证模式 设置为httpBasic模式
         */
        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
                .and().formLogin();

    }
```

#### 配置权限策略

##### 相关 Config 修改

```Java
@Component
@EnableWebSecurity
public class SecurityConfig2 extends WebSecurityConfigurerAdapter {
    /**
     * 新增授权账户
     *
     * @param auth
     * @throws Exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        /**
         * 新增一个账户mayikt 密码也是为mayikt 可以允许访问所有的请求
         */
        auth.inMemoryAuthentication().withUser("mayikt").password("mayikt").authorities("/");

        /**
         * 当前 账户授权 可以访问哪些接口
         */
        auth.inMemoryAuthentication().withUser("mayikt_add").password("mayikt_add").authorities("addMember");
        auth.inMemoryAuthentication().withUser("mayikt_update").password("mayikt_update").authorities("updateMember");
        auth.inMemoryAuthentication().withUser("mayikt_show").password("mayikt_admin").authorities("showMember");
        auth.inMemoryAuthentication().withUser("mayikt_del").password("mayikt_del").authorities("delMember");
    }

    /**
     * 新增 HttpSecurity配置
     *
     * @param http
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
//        /**
//         * 拦截 http 安全认证模式 设置为httpBasic模式
//         */
//        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
//                .and().httpBasic();

//        /**
//         * 拦截 http 安全认证模式 设置为httpBasic模式
//         */
//        http.authorizeRequests().antMatchers("/**").fullyAuthenticated()
//                .and().formLogin();
        http.authorizeRequests().antMatchers("/addMember").hasAnyAuthority("addMember")
                .antMatchers("/delMember").hasAnyAuthority("delMember")
                .antMatchers("/updateMember").hasAnyAuthority("updateMember")
                .antMatchers("/showMember").hasAnyAuthority("showMember")
                // 可以允许login 不被拦截
                .antMatchers("/login").permitAll()
                // 设置自定义登录页面
                .antMatchers("/**").fullyAuthenticated().and().formLogin()
                .loginPage("/login").and().csrf().disable();

    }

    @Bean
    public static NoOpPasswordEncoder passwordEncoder() {
        return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
    }
}
```

##### 修改权限不足页面

![image-20220704213408673](SpringSecurity+Oauth2学习.assets/image-20220704213408673.png)

新增一个 错误异常类

```Java
/**
 * 自定义SpringBoot 错误异常
 */
@Configuration
public class WebServerAutoConfiguration {
    @Bean
    public ConfigurableServletWebServerFactory webServerFactory() {
        TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
        ErrorPage errorPage400 = new ErrorPage(HttpStatus.BAD_REQUEST, "/error/400");
        ErrorPage errorPage401 = new ErrorPage(HttpStatus.UNAUTHORIZED, "/error/401");
        ErrorPage errorPage403 = new ErrorPage(HttpStatus.FORBIDDEN, "/error/403");
        ErrorPage errorPage404 = new ErrorPage(HttpStatus.NOT_FOUND, "/error/404");
        ErrorPage errorPage415 = new ErrorPage(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "/error/415");
        ErrorPage errorPage500 = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/error/500");
        factory.addErrorPages(errorPage400, errorPage401, errorPage403, errorPage404, errorPage415, errorPage500);
        return factory;
    }
}
```

```Java
/**
 * 统一返回错误异常类
 */
@RestController
public class ErrorController {
    @RequestMapping("/error/403")
    public String error() {
        return "您当前访问的接口权限不足!";
    }
}
```

#### 动态权限控制

##### Rbac 权限模型

RBAC（基于角色的权限控制）模型的核心是在用户和权限之间引入了角色的概念。取消了用户和权限的直接关联，改为通过用户关联角色、角色关联权限的方法来间接地赋予用户权限（如下图），从而达到用户和权限解耦的目的。

![image-20220704214208305](SpringSecurity+Oauth2学习.assets/image-20220704214208305.png)

##### Maven 依赖

```xml
<!--  springboot 整合web组件-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<!--spring-boot-starter-security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-freemarker</artifactId>
</dependency>
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>1.0.9</version>
</dependency>
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>8.0.29</version>
</dependency>
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>2.1.2</version>
</dependency>
<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.18.24</version>
    <scope>provided</scope>
</dependency>
```

##### 配置文件

```yml
spring:
  freemarker:
    settings:
      classic_compatible: true #处理空值
      datetime_format: yyy-MM-dd HH:mm
      number_format: 0.##
    suffix: .ftl
    template-loader-path:
      - classpath:/templates
  datasource:
    name: test
    url: jdbc:mysql://127.0.0.1:3306/oatuh?serverTimezone=UTC&useUnicode=true&zeroDateTimeBehavior=convertToNull&autoReconnect=true&characterEncoding=utf-8
    username: root
    password: 123456
   # druid 连接池
    type: com.alibaba.druid.pool.DruidDataSource
    driver-class-name: com.mysql.cj.jdbc.Driver
```

##### WebSecurity 相关配置

```Java
@Component
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private PermissionMapper permissionMapper;
    @Autowired
    private MemberDetailsService memberDetailsService;

    /**
     * 新增Security 授权的账户
     *
     * @param auth
     * @throws Exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//        /**
//         * 需要经过mayikt_admin
//         */
//        auth.inMemoryAuthentication().withUser("mayikt_admin").password("mayikt_admin").authorities("addMember",
//                "delMember", "updateMember", "showMember");
//        /**
//         * 当前 账户授权 可以访问哪些接口
//         */
//        auth.inMemoryAuthentication().withUser("mayikt_add").password("mayikt_add").authorities("addMember");
//        auth.inMemoryAuthentication().withUser("mayikt_update").password("mayikt_update").authorities("updateMember");
//        auth.inMemoryAuthentication().withUser("mayikt_show").password("mayikt_admin").authorities("showMember");
//        auth.inMemoryAuthentication().withUser("mayikt_del").password("mayikt_del").authorities("delMember");
        auth.userDetailsService(memberDetailsService).passwordEncoder(new PasswordEncoder() {
            @Override
            public String encode(CharSequence rawPassword) {
                return MD5Util.encode((String) rawPassword);
            }

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                // md5 传递密码 传递密码 MD5 加密 ===DB中密码 密码输入正确的
                String rawPass = MD5Util.encode((String) rawPassword);
                boolean result = rawPass.equals(encodedPassword);
                return result;
            }
        });
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 配置认证方式 token form 表单 设置为httpBasic模式
//        http.authorizeRequests().antMatchers("/**").fullyAuthenticated().and().httpBasic();
        //拦截 http 安全认证模式 设置为formLogin模式
//        http.authorizeRequests().antMatchers("/**").fullyAuthenticated().and().formLogin();

        /**
         * /addMember  addMember
         * /updateMember  updateMember
         * /delMember  delMember
         * /showMember  showMember
         *
         * mayikt_add----（addMember）
         * mayikt_admin----（addMember，delMember,updateMember,showMember）
         */
//        http.authorizeRequests().antMatchers("/addMember").hasAnyAuthority("addMember")
//                .antMatchers("/delMember").hasAnyAuthority("delMember")
//                .antMatchers("/updateMember").hasAnyAuthority("updateMember")
//                .antMatchers("/showMember").hasAnyAuthority("showMember")
//                // 可以允许login 不被拦截
//                .antMatchers("/login").permitAll()
//                // 设置自定义登录页面
//                .antMatchers("/**").fullyAuthenticated().and().formLogin()
//                .loginPage("/login").and().csrf().disable();

        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry
                authorizeRequests = http.authorizeRequests();
        // 1.需要查询到所有的权限
        List<PermissionEntity> allPermission = permissionMapper.findAllPermission();
        allPermission.forEach((p -> {
            // 将该规则添加
            authorizeRequests.antMatchers(p.getUrl()).hasAnyAuthority(p.getPermTag());
        }));
        //
        // 可以允许login 不被拦截
        authorizeRequests.antMatchers("/login").permitAll()
                // 设置自定义登录页面
                .antMatchers("/**").fullyAuthenticated().and().formLogin()
                .loginPage("/login").and().csrf().disable();

    }

    /**
     * There is no PasswordEncoder mapped for the id "null"
     * 原因:升级为Security5.0以上密码支持多中加密方式，恢复以前模式
     *
     * @return
     */
    @Bean
    public static NoOpPasswordEncoder passwordEncoder() {
        return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
    }
}
```

##### Mapper 接口

用户 mapper

```Java
public interface UserMapper {
    /**
     * 根据用户名称查询
     *
     * @param userName
     * @return
     */
    @Select(" select * from sys_user where username = #{userName}")
    UserEntity findByUsername(@Param("userName") String userName);

    /**
     * 查询用户的权限根据用户查询权限
     *
     * @param userName
     * @return
     */
    @Select(" select permission.* from sys_user user" + " inner join sys_user_role user_role"
            + " on user.id = user_role.user_id inner join "
            + "sys_role_permission role_permission on user_role.role_id = role_permission.role_id "
            + " inner join sys_permission permission on role_permission.perm_id = permission.id where user.username = #{userName};")
    List<PermissionEntity> findPermissionByUsername(@Param("userName") String userName);
}
```

权限 Mapper

```java 
public interface PermissionMapper {

    @Select(" select * from sys_permission ")
    List<PermissionEntity> findAllPermission();

}
```

##### 动态根据名称查询权限

```Java
@Component
public class MemberDetailsService implements UserDetailsService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        // 1.登录的时候 调用该方法 userName查询账户是否存在 在验证账户的密码
        UserEntity userEntity = userMapper.findByUsername(userName);
        if (userEntity == null) {
            return null;
        }
        // 2.在根据该账户的 userid 关联查询 角色对应权限 动态添加
        List<PermissionEntity> userListpermission = userMapper.findPermissionByUsername(userName);
        // 设置的权限
        ArrayList<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        userListpermission.forEach((p -> {
            ///        auth.inMemoryAuthentication().withUser("mayikt_del").password("mayikt_del").authorities("delMember");
            grantedAuthorities.add(new SimpleGrantedAuthority(p.getPermTag()));
        }));
        userEntity.setAuthorities(grantedAuthorities);
        return userEntity;
    }
}
```

##### Entity 

用户 entity

```Java
// 用户信息表
@Data
public class UserEntity implements UserDetails {

   private Integer id;
   private String username;
   private String realname;
   private String password;
   private Date createDate;
   private Date lastLoginTime;
   private boolean enabled;
   private boolean accountNonExpired;
   private boolean accountNonLocked;
   private boolean credentialsNonExpired;
   // 用户所有权限
   private List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

   public Collection<? extends GrantedAuthority> getAuthorities() {

      return authorities;
   }
}
```

```Java
角色 entity
@Data
public class RoleEntity {
   private Integer id;
   private String roleName;
   private String roleDesc;
}
```

```Java
权限 entity
@Data
public class PermissionEntity {
   private Integer id;
   // 权限名称
   private String permName;
   // 权限标识
   private String permTag;
   // 请求url
   private String url;
}
```

## 整合 Oauth2

### 什么是  Oauth ?

OAuth 2.0 是一个授权协议，它允许软件应用代表（而不是充当）资源拥有者去访问资源拥有者的资源。应用向资源拥有者请求授权，然后取得令牌（token），并用它来访问资源，并且资源拥有者不用向应用提供用户名和密码等敏感数据。

### Oauth 应用场景

**1.**   **第三方联合登录** **比如QQ、微信联合登录**

**2.**   **开放接口** **蚂蚁金服腾讯开放接口**

### SpringSecurity 整合 Oauth2

**Maven 依赖**

```xml
<!-- SpringBoot整合Web组件 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
</dependency>

<!-- springboot整合freemarker -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-freemarker</artifactId>
</dependency>

<!-->spring-boot 整合security -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>

<!-- Spring Security OAuth2 -->
<dependency>
    <groupId>org.springframework.security.oauth</groupId>
    <artifactId>spring-security-oauth2</artifactId>
    <version>2.2.1.RELEASE</version>
</dependency>


<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
    <version>0.6.0</version>
</dependency>
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>fastjson</artifactId>
    <version>1.2.62</version>
</dependency>
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
</dependency>
```

**配置类**

```Java
@Component
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * 需要填写 认证账户  mayikt
     * @param auth
     * @throws Exception
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.
                inMemoryAuthentication()
                .withUser("mayikt")
                .password(passwordEncoder().encode("mayikt"))
                .authorities("/*");

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated() //所有请求都需要通过认证
                .and()
                .httpBasic() //Basic登录
                .and()
                .csrf().disable(); //关跨域保护
    }
}
```

**服务认证**

```Java
@Component
@EnableAuthorizationServer
public class AuthorizationConfig extends AuthorizationServerConfigurerAdapter {
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        //允许表单提交
        security.allowFormAuthenticationForClients()
                .checkTokenAccess("permitAll()");
    }

    /**
     * appid mayikt secret= 123456
     *
     * @param clients
     * @throws Exception
     */
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
                // appid
                .withClient("mayikt")
                // appsecret
                .secret(passwordEncoder.encode("123456"))
                // 授权码
                .authorizedGrantTypes("authorization_code")
                // 作用域
                .scopes("all")
                // 资源的id
                .resourceIds("mayikt_resource")
                // 回调地址
                .redirectUris("http://www.mayikt.com/callback");


    }
}
```

## JWT

### 简介

JSON WEB Token JWT的声明一般被用来在身份提供者和服务提供者间传递被认证的用户身份信息，以便于从资源服务器获取资源，也可以增加一些额外的其它业务逻辑所必须的声明信息，该token也可直接被用于认证，也可被加密。

官网：https://jwt.io/ 

### **传统的token**

传统的Token，例如：用户登录成功生成对应的令牌，key为令牌 value：userid，隐藏了数据真实性 ,同时将该token存放到redis中，返回对应的真实令牌给客户端存放。

客户端每次访问后端请求的时候，会传递该token在请求中，服务器端接收到该token之后，从redis中查询如果存在的情况下，则说明在有效期内，如果在Redis中不存在的情况下，则说明过期或者token错误。

### JWT 组成部分

1.第一部分：header （头部）

{

 Typ="jwt" ---类型为jwt

 Alg:"HS256" --加密算法为hs256

}

2.第二部分：playload（载荷）  携带存放的数据  用户名称、用户头像之类 注意铭感数据

标准中注册的声明 (建议但不强制使用) ：

iss: jwt签发者

sub: jwt所面向的用户

aud: 接收jwt的一方

exp: jwt的过期时间，这个过期时间必须要大于签发时间

nbf: 定义在什么时间之前，该jwt都是不可用的.

iat: jwt的签发时间

jti: jwt的唯一身份标识，主要用来作为一次性token,从而回避重放攻击。

3.第三部分：Signature(签名）

**JWT优缺点**

**优点：**

**1.** **无需再服务器存放用户的数据，减轻服务器端压力**

**2.** **轻量级、json风格比较简单**

**3.** **跨语言**

**缺点：**

**jwt**一旦生成后期无法修改：

**1.** **无法更新jwt有效期**

**2.** **无法销毁一个jwt**

**jwt 90天以后过期 提前60天过期**

**JWT的应用场景**

前端分离项目、（移动app、小程序、H5）

**Base64**

Base64不是加密和解密 主要是 编码和解码 基于64个可打印字符来表示二进制数据

https://baike.baidu.com/item/base64/8545775?fr=aladdin

https://base64.us/ 

header  头部：

{

"typ":"jwt",

"alg":"HS256"

}

ewoidHlwIjoiand0IiwKImFsZyI6IkhTMjU2Igp9

playload 存放的数据

{

"userName":"mayikt",

"age":"28"

}

cGxheWxvYWQ=

secret=Base64(header .playload) 

https://base64.us/

**简单手写jwt**

```java 
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.Md5Crypt;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

public class JWTDemo04 {

    public static void main(String[] args) throws UnsupportedEncodingException {
        String jwtSecret="mayikt";
        // jwt jwtHeader
        JSONObject jwtHeader = new JSONObject();
        jwtHeader.put("alg","HS256");
        jwtHeader.put("typ","jwt");
        // jwt playload 
        JSONObject jwtPlayload = new JSONObject();
        jwtPlayload.put("userName","yushengjun644");
        jwtPlayload.put("age",22);
        //base64JwtHeader
        String base64JwtHeader= Base64.getEncoder().encodeToString(jwtHeader.toJSONString().getBytes());
        String base64JwtPlayload= Base64.getEncoder().encodeToString(jwtPlayload.toJSONString().getBytes());
        // 使用MD5 生成签名
        String signature = DigestUtils.md5Hex(jwtPlayload.toJSONString() + jwtSecret);
        String jwt=base64JwtHeader+"."+base64JwtPlayload+"."+signature;
        System.out.println(jwt);
        // 解密
        String jwtPlayloadStr=new String(Base64.getDecoder().decode(jwt.split("\\.")[1].getBytes()),
                "UTF-8");
        String jwtsignatureStr=jwt.split("\\.")[2];
        System.out.println(DigestUtils.md5Hex(jwtPlayloadStr+jwtSecret).equals(jwtsignatureStr));


    }
}
```

**实际项目整合jwt**

maven依赖：

```xml
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
    <version>0.6.0</version>
</dependency>
```

登录接口：

```java 
import com.alibaba.fastjson.JSONObject;
import com.mayikt.api.base.BaseApiService;
import com.mayikt.api.base.BaseResponse;
import com.mayikt.api.member.dto.req.UserLoginDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

public interface JWTLoginService {
    /**
     * jwt登录的方式
     *
     * @return
     */
    @PostMapping("loginJwt")
    BaseResponse<JSONObject> loginJwt(@RequestBody UserLoginDto userLoginDto);

    /**
     * jwt 验证
     *
     * @return
     */
    @GetMapping("jwtVerification")
    BaseResponse<JSONObject> jwtVerification(@RequestParam("jwt") String jwt);
}
```

```java 
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mayikt.api.base.BaseApiService;
import com.mayikt.api.base.BaseResponse;
import com.mayikt.api.impl.entity.UserInfoDo;
import com.mayikt.api.impl.mapper.UserInfoMapper;
import com.mayikt.api.impl.utils.MayiktJwtUtils;
import com.mayikt.api.member.JWTLoginService;
import com.mayikt.api.member.dto.req.UserLoginDto;
import com.mayikt.api.utils.MD5Util;
import io.jsonwebtoken.Claims;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JWTLoginServiceImpl extends BaseApiService<JSONObject> implements JWTLoginService {
    @Autowired
    private UserInfoMapper userInfoMapper;

    @Override
    public BaseResponse<JSONObject> loginJwt(UserLoginDto userLoginDto) {
        // 验证参数
        String mobile = userLoginDto.getMobile();
        if (StringUtils.isEmpty(userLoginDto.getMobile())) {
            return setResultError("mobile 不能为空!");
        }
        String passWord = userLoginDto.getPassWord();
        if (StringUtils.isEmpty(userLoginDto.getPassWord())) {
            return setResultError("passWord 不能为空!");
        }
        // md5加密
        String newPassWord = MD5Util.MD5(passWord);
        QueryWrapper<UserInfoDo> userInfoDoQueryWrapper = new QueryWrapper<>();
        userInfoDoQueryWrapper.eq("MOBILE", mobile);
        userInfoDoQueryWrapper.eq("PASSWORD", newPassWord);
        UserInfoDo userInfoDo = userInfoMapper.selectOne(userInfoDoQueryWrapper);
        if (userInfoDo == null) {
            return setResultError("手机号码或者密码错误");
        }
        // 生成jwttoken
        String jwt = MayiktJwtUtils.generateJsonWebToken(userInfoDo);
        JSONObject data = new JSONObject();
        data.put("jwt", jwt);
        return setResultSuccess(data);
    }

    @Override
    public BaseResponse<JSONObject> jwtVerification(String jwt) {
        if (StringUtils.isEmpty(jwt)) {
            return setResultError("jwt is null");
        }
        Claims claims = MayiktJwtUtils.checkJWT(jwt);
        if(claims==null){
            return setResultError("jwt error");
        }
        return setResultSuccess();
    }

}
```

**Jwt**如何实现注销

1. 浏览器cookie清除(但是服务器还是存在)

2. 建议将时间设置稍微短一点

- jwt有效期 90天 无法提前过期
- jwt 有效期180天 用户退出