import java.util.ArrayList;
import java.util.List;

/**
 * TODO
 *
 * @author wpw
 * @since 2022/7/10
 */

public class Test {
    public static void main(String[] args) {
        System.out.println(lenLongestFibSubseq(new int[]{1,3,7,11,12,14,18}));
    }

    public static int lenLongestFibSubseq(int[] arr) {
        int len = arr.length;
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < len; i++) {
            list.add(arr[i]);
        }
        int x = 0;
        int y = 1;
        int res = 0;
        for (int i = 0; ; i++) {
            int temp = x + y;
            if (list.contains(temp)) {
                res++;
            } else {
                if(temp > list.get(len - 1)) {
                    break;
                }
            }
            x = y;
            y = temp;
        }
        return res;
    }
}
