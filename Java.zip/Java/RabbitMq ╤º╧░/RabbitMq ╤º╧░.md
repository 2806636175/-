# RabbitMq 学习

### 一、 什么是消息中间件？

消息中间件基于队列模型实现异步/同步传输数据

**作用**：可以实现支撑高并发、异步解耦、流量削峰、降低耦合度。

### 二、传统 Http 请求存在的缺点

1. Http请求基于请求与响应的模型，在高并发的情况下，客户端发送大量的请求达到达服务器端有可能会导致我们服务器端处理请求堆积。
2. Tomcat服务器处理每个请求都有自己独立的线程，如果超过最大线程数会将该请求缓存到队列中，如果请求堆积过多的情况下，有可能会导致tomcat服务器崩溃的问题。所以一般都会在nginx入口实现限流，整合服务保护框架。

![img](图片/clip_image002.jpg)

3. http请求处理业务逻辑如果比较耗时的情况下，容易造成客户端一直等待，阻塞等待过程中会导致客户端超时发生重试策略，有可能会引发幂等性问题。

**注意事项**：接口是为http协议的情况下，最好不要处理比较耗时的业务逻辑，耗时的业务逻辑应该单独交给多线程或者是mq处理。

### 三、MQ 应用场景

1. 异步发送短信
2. 异步发送新人优惠券
3. 处理一些比较耗时的操作

### 四、使用 MQ 的好处

可以实现支撑高并发、异步解耦、流量削峰、降低耦合度。

### 五、MQ 与多线程之间的区别

- MQ可以实现异步/解耦/流量削峰问题；
- 多线程也可以实现异步，但是消耗到cpu资源，没有实现解耦。

### 六、MQ 消息中间件名词

- Producer 生产者：投递消息到MQ服务器端；
- Consumer 消费者：从MQ服务器端获取消息处理业务逻辑；
- Broker  MQ服务器端
- Topic 主题：分类业务逻辑发送短信主题、发送优惠券主题
- Queue 存放消息模型 队列 先进先出 后进后出原则 数组/链表
- Message 生产者投递消息报文：json

### 七、使用 MQ 常见的问题

1. **如何避免消息丢失问题？（如果 MQ 服务器端宕机后，如何保证消息不丢失）**

- 持久化机制

2. **当 MQ 接收到生产者投递的消息，如果消费者不存在的情况下，消息是否会丢失？**

- 不会，MQ 会有消息确认机制，必须消费者消费消息后，在通知 MQ 服务器端删除该消息

3. **MQ 如何实现抗高并发思想？**

- MQ 根据自身能力，拉去 MQ 服务器端消息消费，默认情况是拉取一条，生产者生产的消息会先缓存在 MQ 服务器端，缺点是存在延迟问题

4. **如何提高 MQ 消费者速率**

- 消费者实现集群、消费者批量获取消息即可。

### 八、 主流 MQ 对比区别

| 特性       | ActiveMQ                                                     | RabbitMQ                                                     | RocketMQ                 | kafka                                                        |
| :--------- | ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------ | ------------------------------------------------------------ |
| 开发语言   | java                                                         | erlang                                                       | java                     | scala                                                        |
| 单机吞吐量 | 万级                                                         | 万级                                                         | 10万级                   | 10万级                                                       |
| 时效性     | ms级                                                         | us级                                                         | ms级                     | ms级以内                                                     |
| 可用性     | 高（主从架构）                                               | 高（主从架构）                                               | 非常高（分布式架构）     | 非常高（分布式架构）                                         |
| 功能特性   | 成熟的产品，在很多公司得到应用；有较多的文档；各种协议支持较好 | 基于erlang开发，所以并发能力很强，性能极其好，延时很低管理界面较丰富 | MQ功能比较完备，扩展性佳 | 只支持主要的MQ功能，像一些消息查询，消息回溯等功能没有提供，毕竟是为大数据准备的，在大数据领域应用广。 |

### 九、Rabbit Mq 简单介绍

RabbitMQ是实现了高级消息队列协议（AMQP）的开源消息代理软件（亦称面向消息的中间件），RabbitMQ服务器是用Erlang语言编写的。

RabitMQ官方网站:  https://www.rabbitmq.com/

![img](图片/clip_image002-16495976750551.jpg)

![img](图片/clip_image002-16495976880482.jpg)

1. 点对点(简单)的队列

2. 工作(公平性)队列模式

3. 发布订阅模式

4. 路由模式Routing

5. 通配符模式Topics

6. RPC

    https://www.rabbitmq.com/getstarted.html

### 十、RabbitMq 常见名词

- Virtual Hosts -- 分类
- quene -- 队列												
- exchange -- 交换机，用于分派我们消息到哪个队列中去

### 十一、快速入门简单Rabbit MQ 队列

**Maven 依赖**

```xml
<dependency>
    <groupId>com.rabbitmq</groupId>
    <artifactId>amqp-client</artifactId>
    <version>3.6.5 </version>
</dependency>
```

**与 Rabbit MQ 建立连接代码**

```Java
/**
 * 连接 Rabbit MQ
 *
 * @author wpw
 * @since 2022/4/14
 */
public class RabbitMqConnection {

    /**
     * 获取连接
     *
     * @return
     */
    public static Connection  getConnection() throws IOException, TimeoutException {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        // 设置连接到virtual host
        connectionFactory.setVirtualHost("/virtualHost");
        // 设置账号密码
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        // mq连接信息地址
        connectionFactory.setHost("101.132.65.100");
        connectionFactory.setPort(5672);
        return connectionFactory.newConnection();
    }
}
```

**生产者代码**

```Java
/**
 * 生产者
 *
 * @author wpw
 * @since 2022/4/14
 */
public class Producer {
    public static String Queue_Name = "queue";

    public static void main(String[] args) throws IOException, TimeoutException {
        // 获取连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建通道
        Channel channel = connection.createChannel();
        // 发送消息
        String msg = "test";
        channel.basicPublish("", Queue_Name, null, msg.getBytes() );
        channel.close();

    }
}
```

**消费者代码**

```Java
/**
 * 消费者
 *
 * @author wpw
 * @since 2022/4/14
 */
public class Consumer {
    public static String Queue_Name = "queue";

    public static void main(String[] args) throws IOException, TimeoutException {
        // 创建连接
        Connection connection = RabbitMqConnection.getConnection();
        // 设置通道
        Channel channel = connection.createChannel();
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws UnsupportedEncodingException {
                String msg = new String(body, "UTF-8");
                System.out.println("消费者获取消息:" + msg);
            }
        };
        // 3.监听队列
        // autoAck 为true:表示自动签收 false:手动签收模式
        channel.basicConsume(Queue_Name, true, defaultConsumer);

    }
}
```

### 十二、Rabbit MQ 如何保证消息不丢失

**Mq 如何保证消息不丢失：**

1. 生产者

- 确保生产者投递消息到 MQ 服务器端成功
  - `ACK 消息确认机制`（方式一：Confirms 方式二：事务消息）
  - 同步或者异步的形式（通过异步的形式用一个观察者模式监听消息是否发送成功，然后进行回调）

2. 消费者

- 必须将消息进行消费成功之后，才会将消息从 MQ 服务器端移除。（Kafaka 中即使消费消息成功后也不会立即将消息从服务器端移除）

3. 服务器端

- 在默认的情况下都会对队列中的消息进行持久化，持久化到硬盘。

**消息确认和事务回滚相关代码**

```Java
/**
 * Rabbit Mq 消息确认机制
 *
 * @author wpw
 * @since 2022/4/16
 */
public class MessageConfirm {
    public static String Queue_Name = "queue";
    /**
     * 生产者消息确认机制
     *
     * @param args
     */
    public static void main(String[] args) {
        try {
            // 建立一个连接
            Connection connection = RabbitMqConnection.getConnection();
            // 创建一个通道
            Channel channel = connection.createChannel();
            // 发送消息
            String msg = "test";
            channel.confirmSelect();
            channel.basicPublish("", Queue_Name, null, msg.getBytes());
            boolean result = channel.waitForConfirms();
            if (result) {
                System.out.println("消息投递成功");
            } else {
                System.out.println("消息投递失败");
            }
            channel.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Rabbit Mq事务消息
     *
     * @param args
     */
    public static void main(String[] args) throws IOException, TimeoutException {
        // 建立一个连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建一个通道
        Channel channel = connection.createChannel();
        try {
            // 发送消息
            String msg = "test";
            channel.txSelect();
            channel.basicPublish("", Queue_Name, null, msg.getBytes());
            int i = 1 / 0;
            channel.txCommit();

            System.out.println("消息投递成功");
            channel.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            // 消息投递失败进行回滚
            if (channel != null) {
                channel.txRollback();
            }
        }
    }
}
```

### 十三、Rabbit MQ 五种消息模式

**Rabbit Mq 工作队列**

默认的传统队列是为均摊消费，存在不公平性；如果每个消费者速度不一样的情况下，均摊消费是不公平的，应该是能者多劳。

![img](图片/clip_image002-16501950128051.jpg)

采用工作队列 

在通道中只需要设置basicQos为1即可，表示MQ服务器每次只会给消费者推送1条消息必须手动ack确认之后才会继续发送。

### 十四、MQ 交换机类型

- Direct exchange（直连交换机）
- Fanout exchange（扇型交换机）
- Topic exchange（主题交换机）
- Headers exchange（头交换机）
- /Virtual Hosts---区分不同的团队
- ----队列 存放消息
- ----交换机 路由消息存放在那个队列中 类似于nginx
- ---路由key 分发规则

#### RabbitMQ Fanout 发布订阅

生产者发送一条消息，经过交换机转发到多个不同的队列，多个不同的队列就多个不同的消费者。

![img](图片/clip_image002-16501965437622.jpg)

![img](图片/clip_image002-16501965522523.jpg)

原理：

1. 需要创建两个队列 ，每个队列对应一个消费者；

2. 队列需要绑定我们交换机

3. 生产者投递消息到交换机中，交换机在将消息分配给两个队列中都存放起来；

4. 消费者从队列中获取这个消息。

**生产者代码**

```Java
package com.rabbitmq.demo03;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.study.RabbitMqConnection;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class ProducerFanout {

    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "fanout_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        //  创建Connection
        Connection connection = RabbitMqConnection.getConnection();
        // 创建Channel
        Channel channel = connection.createChannel();
        // 通道关联交换机
        channel.exchangeDeclare(EXCHANGE_NAME, "fanout", true);
        String msg = "test";
        channel.basicPublish(EXCHANGE_NAME, "", null, msg.getBytes());
        channel.close();
        connection.close();
    }

}
```

**邮件消费者代码**

```Java
package com.rabbitmq.demo03;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.study.RabbitMqConnection;

public class MailConsumer {
    /**
     * 定义邮件队列
     */
    private static final String QUEUE_NAME = "fanout_email_queue";
    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "fanout_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        System.out.println("邮件消费者...");
        // 创建我们的连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建我们通道
        final Channel channel = connection.createChannel();
        // 关联队列消费者关联队列
        channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, "");
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg = new String(body, "UTF-8");
                System.out.println("邮件消费者获取消息:" + msg);
            }
        };
        // 开始监听消息 自动签收
        channel.basicConsume(QUEUE_NAME, true, defaultConsumer);

    }
}
```

**短信消费者代码**

```Java
package com.rabbitmq.demo03;

import com.rabbitmq.client.*;
import com.rabbitmq.study.RabbitMqConnection;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class SmsConsumer {
    /**
     * 定义短信队列
     */
    private static final String QUEUE_NAME = "fanout_email_sms";
    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "fanout_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        System.out.println("短信消费者...");
        // 创建我们的连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建我们通道
        final Channel channel = connection.createChannel();
        // 关联队列消费者关联队列
        channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, "");
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg = new String(body, "UTF-8");
                System.out.println("短信消费者获取消息:" + msg);
            }
        };
        // 开始监听消息 自动签收
        channel.basicConsume(QUEUE_NAME, true, defaultConsumer);

    }
}
```

#### Direct路由模式

当交换机类型为direct类型时，根据队列绑定的路由建转发到具体的队列中存放消息

![img](图片/clip_image002-16501977057804.jpg)

**生产者代码**

```Java
package com.rabbitmq.demo04;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.study.RabbitMqConnection;

public class ProducerDirect {

    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "direct_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        //  创建Connection
        Connection connection = RabbitMqConnection.getConnection();
        // 创建Channel
        Channel channel = connection.createChannel();
        // 通道关联交换机
        channel.exchangeDeclare(EXCHANGE_NAME, "direct", true);
        String msg = "test";
        channel.basicPublish(EXCHANGE_NAME, "email", null, msg.getBytes());
        channel.close();
        connection.close();
    }

}
```

**邮件消费者代码**

```Java
package com.rabbitmq.demo04;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.study.RabbitMqConnection;

public class MailConsumer {
    /**
     * 定义邮件队列
     */
    private static final String QUEUE_NAME = "direct_email_queue";
    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "direct_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        System.out.println("邮件消费者...");
        // 创建我们的连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建我们通道
        final Channel channel = connection.createChannel();
        // 关联队列消费者关联队列
        channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, "email");
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg = new String(body, "UTF-8");
                System.out.println("邮件消费者获取消息:" + msg);
            }
        };
        // 开始监听消息 自动签收
        channel.basicConsume(QUEUE_NAME, true, defaultConsumer);

    }
}
```

**短信消费者代码**

```Java
package com.rabbitmq.demo04;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.study.RabbitMqConnection;

public class SmsConsumer {
    /**
     * 定义短信队列
     */
    private static final String QUEUE_NAME = "direct_sms_queue";
    /**
     * 定义交换机的名称
     */
    private static final String EXCHANGE_NAME = "direct_exchange";

    public static void main(String[] args) throws IOException, TimeoutException {
        System.out.println("短信消费者...");
        // 创建我们的连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建我们通道
        final Channel channel = connection.createChannel();
        // 关联队列消费者关联队列
        channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, "sms");
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg = new String(body, "UTF-8");
                System.out.println("短信消费者获取消息:" + msg);
            }
        };
        // 开始监听消息 自动签收
        channel.basicConsume(QUEUE_NAME, true, defaultConsumer);

    }
}
```

#### Topic主题模式

当交换机类型为topic类型时，根据队列绑定的路由建模糊转发到具体的队列中存放。

1. `#`号表示支持匹配多个词
2. `*`号表示只能匹配一个词

![img](图片/clip_image002-16501981031725.jpg)

![image-20220417202638007](图片/image-20220417202638007.png)

### 十五、生产者如何拿到消费结果

**1.**   **根据业务来定**

**2.**   **Rocketmq** **自带全局消息id，能够根据该全局消息获取消费结果**

原理： 生产者投递消息到mq服务器，mq服务器端在这时候返回一个全局的消息id，

当我们消费者消费该消息成功之后，消费者会给我们mq服务器端发送通知标记该消息

消费成功。

生产者获取到该消息全局id，每隔2s时间调用mq服务器端接口查询该消息是否

有被消费成功。

### 十六、Rabbit Mq 死信队列

**死信队列的产生背景**

RabbitMQ死信队列俗称，备胎队列；消息中间件因为某种原因拒收该消息后，可以转移到死信队列中存放，死信队列也可以有交换机和路由key等

**产生死信队列的原因**

1. 消息投递到MQ中存放 消息已经过期 消费者没有及时的获取到我们消息，消息如果存放到mq服务器中过期之后，会转移到备胎死信队列存放。

2. 队列达到最大的长度 （队列容器已经满了）

3. 消费者消费多次消息失败，就会转移存放到死信队列中

![img](图片/clip_image002-16502924154491.jpg)

**死信队列和普通队列的区别**

相同点：普通与死信队列都有自己独立的交换机和路由key、队列和消费者。

不同点：

1. 生产者投递消息先投递到我们普通交换机中，普通交换机在将该消息投到普通队列中缓存起来，普通队列对应有自己独立普通消费者。
2. 如果生产者投递消息到普通队列中，普通队列发现该消息一直没有被消费者消费的情况下，在这时候会将该消息转移到死信（备胎）交换机中，死信（备胎）交换机对应有自己独立的 死信（备胎）队列 对应独立死信（备胎）消费者

**死信队列相关代码**

在声明有死信队列的队列时同时绑定死信队列的交换机和队列

```Java
/**
 * 声明订单队列
 *
 * @return Queue
 */
@Bean
public Queue orderQueue() {
    // 订单队列绑定我们的死信交换机
    Map<String, Object> arguments = new HashMap<>(2);
    arguments.put("x-dead-letter-exchange", dlxExchange);
    arguments.put("x-dead-letter-routing-key", dlxRoutingKey);
    return new Queue(orderQueue, true, false, false, arguments);
}
```

同时生产者发送消息时可以设置消息过期时间

```Java
@RequestMapping("/sendOrder")
public String sendOrder() {
    String msg = "每特教育牛逼";
    rabbitTemplate.convertAndSend(orderExchange, orderRoutingKey, msg, message -> {
        // 设置消息过期时间 10秒过期
        message.getMessageProperties().setExpiration("10000");
        return message;
    });
    return "success";
}
```

**死信队列应用场景**

30 分钟订单超时设计

实现方式：

1. Redis 设置过期 key
2.  死信延迟队列实现：

采用死信队列，创建一个普通队列没有对应的消费者消费消息，在30分钟过后就会将该消息转移到死信备胎消费者实现消费。

备胎死信消费者会根据该订单号码查询是否已经支付过，如果没有支付的情况下则会开始回滚库存操作

### 十七、Rabbit Mq 的消息幂等性问题

rabbit mq 消息自动重试机制

1. 当我们消费者处理执行我们业务代码的时候，如果抛出异常的情况下在这时候mq会自动触发重试机制，默认的情况下rabbitmq是`无限次`数的重试。需要人为指定重试次数限制问题

认为指定重试次数相关代码，**只需指定配置文件就行**

```yml
spring:
  rabbitmq:
    ####连接地址
    host: 101.132.65.100
    ####端口号
    port: 5672
    ####账号
    username: guest
    ####密码
    password: guest
    ### 地址
    virtual-host: /virtualHost
    listener:
      simple:
        retry:
          ####开启消费者（程序出现异常的情况下会）进行重试
          enabled: true
          ####最大重试次数
          max-attempts: 5
          ####重试间隔时间
          initial-interval: 3000
        acknowledge-mode: manual
```

2. 在什么情况下，消费者需要实现重试策略？

A. 消费者获取消息后，调用第三方接口，但是调用第三方接口失败呢？是否需要重试？

- 该情况下需要实现重试策略，网络延迟只是暂时调用不通，重试多次有可能会调用通。

B. 消费者获取消息后，因为代码问题抛出数据异常，是否需要重试？

- 该情况下是不需要实现重试策略，就算重试多次，最终还是失败的。可以将日志存放起来，后期通过定时任务或者人工补偿形式。

如果是重试多次还是失败消息，需要重新发布消费者版本实现消费，可以使用死信队列

- Mq在重试的过程中，有可能会引发消费者重复消费的问题。
- Mq消费者需要解决 幂等性问题
- 幂等性 保证数据唯一
  - 方式1：生产者在投递消息的时候，生成一个全局唯一id，放在我们消息中。
  - 消费者获取到我们该消息，可以根据该全局唯一id实现去重复。
  - 全局唯一id 根据业务来定的 订单号码作为全局的id
  - 实际上还是需要再db层面解决数据防重复。
  - 业务逻辑是在做insert操作 使用唯一主键约束
  - 业务逻辑是在做update操作 使用乐观锁
