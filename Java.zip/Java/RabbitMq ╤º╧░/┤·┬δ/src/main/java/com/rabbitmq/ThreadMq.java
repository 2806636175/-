package com.rabbitmq;

import java.util.concurrent.LinkedBlockingDeque;

/**
 * 基于多线程实现简单 MQ
 *
 * @author wpw
 * @since 2022/4/7
 */
public class ThreadMq {

    private static LinkedBlockingDeque<Object> msgDeque = new LinkedBlockingDeque<Object>();

    public static void main(String[] args) {
        // 生产线程
        Thread producerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        Thread.sleep(1000);
                        msgDeque.offer("test");
                    }
                } catch (Exception e) {

                }
            }
        }, "生产者");
        producerThread.start();
        // 消费者线程
        Thread consumerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        Object poll = msgDeque.poll();
                        if (poll != null) {
                            System.out.println(Thread.currentThread().getName() + "," + poll);
                        }
                    }
                } catch (Exception e) {

                }
            }
        }, "消费者");
        consumerThread.start();
    }
}
