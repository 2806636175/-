package com.rabbitmq.study;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

/**
 * 连接 Rabbit MQ
 *
 * @author wpw
 * @since 2022/4/14
 */
public class RabbitMqConnection {

    /**
     * 获取连接
     *
     * @return
     */
    public static Connection  getConnection() throws IOException, TimeoutException {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        // 设置连接到virtual host
        connectionFactory.setVirtualHost("/virtualHost");
        // 设置账号密码
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        // mq连接信息地址
        connectionFactory.setHost("101.132.65.100");
        connectionFactory.setPort(5672);
        return connectionFactory.newConnection();
    }
}