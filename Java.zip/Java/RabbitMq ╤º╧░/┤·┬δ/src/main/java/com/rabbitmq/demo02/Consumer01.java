package com.rabbitmq.demo02;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.rabbitmq.study.RabbitMqConnection;

/**
 * 消费者
 *
 * @author wpw
 * @since 2022/4/14
 */
public class Consumer01 {
    public static String Queue_Name = "queue";

    public static void main(String[] args) throws IOException, TimeoutException {
        // 创建连接
        Connection connection = RabbitMqConnection.getConnection();
        // 设置通道
        Channel channel = connection.createChannel();
        // 指定消费者每次批量获取消息
        channel.basicQos(2);
        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg = new String(body, "UTF-8");
                System.out.println("消费者获取消息:" + msg);
                // 消费者消费完消息，通知 MQ 删除消息
                channel.basicAck(envelope.getDeliveryTag(), false);
            }
        };
        // 3.监听队列
        // autoAck 为true:表示自动签收 false:手动签收模式
        channel.basicConsume(Queue_Name, false, defaultConsumer);
    }

}
