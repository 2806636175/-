package com.rabbitmq.demo01;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.study.RabbitMqConnection;

/**
 * 生产者
 *
 * @author wpw
 * @since 2022/4/14
 */
public class Producer {
    public static String Queue_Name = "queue";

    public static void main(String[] args) throws IOException, TimeoutException {
        // 获取连接
        Connection connection = RabbitMqConnection.getConnection();
        // 创建通道
        Channel channel = connection.createChannel();
        // 发送消息
        for (int i = 0; i < 10; ++i) {
            String msg = "test";
            channel.basicPublish("", Queue_Name, null, msg.getBytes());
        }
        channel.close();
        connection.close();
    }
}
