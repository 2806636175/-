package com.rabbitmq.demo;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.study.RabbitMqConnection;

/**
 * Rabbit Mq 消息确认机制
 *
 * @author wpw
 * @since 2022/4/16
 */
public class MessageConfirm {
    public static String Queue_Name = "queue";
    /**
     * 生产者消息确认机制
     *
     * @param args
     */
    public static void main(String[] args) {
        try {
            // 建立一个连接
            Connection connection = RabbitMqConnection.getConnection();
            // 创建一个通道
            Channel channel = connection.createChannel();
            // 发送消息
            String msg = "test";
            channel.confirmSelect();
            channel.basicPublish("", Queue_Name, null, msg.getBytes());
            boolean result = channel.waitForConfirms();
            if (result) {
                System.out.println("消息投递成功");
            } else {
                System.out.println("消息投递失败");
            }
            channel.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    /**
//     * Rabbit Mq事务消息
//     *
//     * @param args
//     */
//    public static void main(String[] args) throws IOException, TimeoutException {
//        // 建立一个连接
//        Connection connection = RabbitMqConnection.getConnection();
//        // 创建一个通道
//        Channel channel = connection.createChannel();
//        try {
//            // 发送消息
//            String msg = "test";
//            channel.txSelect();
//            channel.basicPublish("", Queue_Name, null, msg.getBytes());
//            int i = 1 / 0;
//            channel.txCommit();
//
//            System.out.println("消息投递成功");
//            channel.close();
//            connection.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//            // 消息投递失败进行回滚
//            if (channel != null) {
//                channel.txRollback();
//            }
//        }
//    }
}
