package com.study.service;


import com.study.entity.MsgEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 邮件消费者代码
 *
 * @author wpw
 * @since 2022/4/18
 */
@Component
@Slf4j
@RabbitListener(queues = "fanout_sms_queue")
public class FanoutSmsConsumer {
    @RabbitHandler
    public void process(MsgEntity msgEntity) {
        log.info("msg" + msgEntity);
        System.out.println("msg" + msgEntity);
    }
}
