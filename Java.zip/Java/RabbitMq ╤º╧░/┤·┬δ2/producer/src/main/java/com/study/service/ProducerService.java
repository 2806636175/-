package com.study.service;

import java.util.UUID;

import com.study.entity.MsgEntity;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 生产者 Service
 *
 * @author wpw
 * @since 2022/4/17
 */
@RestController
public class ProducerService {

    @Autowired
    private AmqpTemplate amqpTemplate;

    @RequestMapping("/sendMsg")
    public void sendMsg() {
        // 参数1：交换机名
        // 参数2：路由key
        // 参数3：发送的消息
        MsgEntity msgEntity = new MsgEntity(UUID.randomUUID().toString(), "用户1", "152622", "2806636175@qq.com");
        amqpTemplate.convertAndSend("/exchange", "", msgEntity);
    }
}
