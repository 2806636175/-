# 									ClickHouse 学习

[笔记参考网址](https://www.jianshu.com/p/9da0825126a0)

clickhouse在docker[环境下安装教程](https://www.freesion.com/article/15091437940/)

clickhouse[官网学习文档](https://clickhouse.com/docs/en/home/)

###  一、clickhouse简介

​		ClickHouse 是俄罗斯的 Yandex 于 2016 年开源的用于**在线分析处理查询**（OLAP :Online Analytical Processing）**MPP架构**的**列式存储数据库**（DBMS：Database Management System），能够使用 SQL 查询实时生成分析数据报告。ClickHouse的全称是Click Stream，Data WareHouse。

​		ClickHouse的几个显著特点：

- OLAP

  clickhouse的设计定位就是OLAP**离线数据处理**，相比于OLTP**在线事务处理**，clickhouse更关注的是海量数据的计算分析，关注的是数据吞吐、查询速度、计算性能等指标；而对于数据的频繁变更则不是很擅长，所以 clickhouse 通常用来用来构建后端实时数仓或离线数仓

- 列示存储

  clickhouse 是真正意义上的**列式数据库**，传统数据库都是根据行来存储数据的。

  ![image-20221001202903860](ClickHouse 学习.assets/image-20221001202903860-1664627346011-1.png)

​		常用的mysql数据库，他的B+树的叶子节点就是存储的一行数据，如上图所示，这样的好处是当我想查一条数据时我		们能拿到一条完整的数据。

<img src="ClickHouse 学习.assets/image-20221001203355293-1664627636978-3.png" alt="image-20221001203355293" style="zoom:80%;" />

### 二、clickhouse环境安装

使用docker来安装该数据库，安装教程如下：

[参考网址](https://www.freesion.com/article/15091437940/)

### 三、clickhouse 使用

#### merrgeTree

MergeTree引擎是clickhouse的核心。

下面是学习用的创建表语句：

```xml
create table t_stock(
id UInt32,
sku_id String,
total_amount Decimal(16,2),
create_time Datetime
) engine = MergeTree()
partition by toYYYYMMDD(create_time)
primary key (id)
order by (id,sku_id);
```

**partition by 分区键**

分区键作用：主要是降低数据扫描的范围，优化查询速度。

分区表的数据目录：MergeTree引擎默认是以列文件+索引文件+表定义文件共同描述一个表。
