import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class test {
    public static void main(String[] args)  {
        String driverName="ru.yandex.clickhouse.ClickHouseDriver";
        String url="jdbc:clickhouse://101.132.65.100:8123/default";
        String user="default";
        String password="123456";
        String sql="select * from test;";
        String[] params={};
        ConnEntity connEntiy = new ConnEntity(driverName, url, user, password);
        Utils utils = new ClickhouseUtils();
        Connection conn = utils.connection(connEntiy);
        ResultSet resultSet = utils.QueryResultSet(conn, sql, params);
        System.out.println(resultSet);
    }
}