import java.sql.Connection;
import java.sql.ResultSet;

public interface Utils {
    public Connection connection(ConnEntity connEntiy);

    public void close(AutoCloseable... closes);

    public boolean insert(Connection connection, String sql, String... params);

    public boolean delete(Connection connection, String sql, String... params);

    public ResultSet QueryResultSet(Connection connection, String sql, String... params);
}
